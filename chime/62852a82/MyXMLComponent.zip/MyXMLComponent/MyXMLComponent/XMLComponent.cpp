//
//  XMLComponent.cpp
//  MyXMLComponent
//
//  Created by Kjell-Olov Högdahl on 2016-10-09.
//  Copyright © 2016 Kjell-Olov Högdahl. All rights reserved.
//
// Header
#include <string>
#include <vector>
#include <boost/variant.hpp>
#include "external/gsl/gsl"
// Cpp
#include <iostream>
#include <sstream>
#include "XMLComponent.hpp"
// http://grinninglizard.com/tinyxml2docs/index.html
#include "external/tinyxml2/tinyxml2.h"

namespace xml {

    // Header-file
    using Key = std::string;
    using Path = std::vector<Key>;
    using Value = std::string;
    
    using xml_span = gsl::span<const char>;
    using Element = tinyxml2::XMLElement;
    struct Attribute {tinyxml2::XMLElement* m_pElement; Key m_key;}; // Fix! tinyxml2::XMLAttribute* is private in tinyxml2::XMLElement* so we create our own
    using NULLElementPtr = std::nullptr_t;
    using DocumentPtr = tinyxml2::XMLDocument*;
    using ElementPtr = Element*;
    using AttributePtr = std::shared_ptr<Attribute>; // Fix! We need to own Attribute instances
    using ElementPtrVariant = boost::variant<NULLElementPtr,DocumentPtr,ElementPtr,AttributePtr>;
    
    class null_element_write_error : public std::runtime_error {
    public:
        null_element_write_error(const std::string& sMessage) : std::runtime_error(sMessage) {}
    };
    
    namespace detail {
        
        struct is_null : public boost::static_visitor<bool> {
            bool operator()(NULLElementPtr pElement) const {return true;}
            bool operator()(DocumentPtr pElement) const {return (pElement == nullptr);}
            bool operator()(ElementPtr pElement) const { return (pElement == nullptr);}
            bool operator()(AttributePtr pElement) const { return (pElement == nullptr);}
            
        };
        
        struct select_child : boost::static_visitor<ElementPtrVariant> {
            const Key& m_key;
            select_child(const Key& key) : m_key(key) {}
          
            ElementPtrVariant operator()(NULLElementPtr pElement) {
                return ElementPtrVariant(); // null (null element have no childs)
            }
            ElementPtrVariant operator()(DocumentPtr pElement) {
                if (pElement->RootElement() == nullptr) {
                    // Create it
                    pElement->InsertEndChild(pElement->NewElement(m_key.c_str()));
                }
                return ElementPtrVariant(pElement->FirstChildElement(m_key.c_str())->ToElement());
            }
            ElementPtrVariant operator()(ElementPtr pElement) {
                ElementPtrVariant result; // default null
                if (m_key.size()>0) {
                    // m_key is expressed in "key-path language". Return a view of correct element type :)
                    if (m_key[0]=='@') {
                        // match atribute
                        Key attribute_name(m_key.begin()+1,m_key.end()); // strip '@'
                        if (pElement->Attribute(attribute_name.c_str()) == nullptr) {
                            // create the attribute
                            pElement->SetAttribute(attribute_name.c_str(),"");
                        }
                        result = AttributePtr(new Attribute{pElement,attribute_name});
                    }
                    else {
                        // Match element name
                        ElementPtr pChildElement = pElement->FirstChildElement(m_key.c_str());
                        if (pChildElement == nullptr) {
                            // Create it
                            pChildElement = pElement->InsertEndChild(pElement->GetDocument()->NewElement(m_key.c_str()))->ToElement();
                        }
                        result = ElementPtrVariant(pChildElement);
                    }
                }
                return result;
            }
            ElementPtrVariant operator()(AttributePtr pElement) {
                return ElementPtrVariant(); // null (attributes have no childs)
            }
        };
        
        struct key_matches : boost::static_visitor<bool> {
            const Key& m_key;
            key_matches(const Key& key) : m_key(key) {}
            bool operator()(const NULLElementPtr pElement) const { return false;}
            bool operator()(const DocumentPtr pElement) const {
                return this->operator()(pElement->RootElement()); // delegate
            }
            bool operator()(const ElementPtr pElement) const {
                return (m_key == pElement->Name());
            }
            bool operator()(const AttributePtr pElement) const {
                Key attribute_key_name(m_key.begin()+1,m_key.end()); // Skip '@' in attribute key
                return (attribute_key_name == pElement->m_key);
            }
        };
        
        struct element_value_assigner : public boost::static_visitor<> {
            const Value& m_value;
            element_value_assigner(const Value& value) : m_value(value) {}
            void operator()(const NULLElementPtr pElement) {
                throw null_element_write_error("Can't assign to null element.");
            }
            void operator()(const DocumentPtr pElement) {
                return this->operator()(pElement->RootElement()); // delegate
            }
            void operator()(const ElementPtr pElement) {
                if (pElement != nullptr) {
                    pElement->SetText(m_value.c_str());
                }
                else {
                    throw null_element_write_error("Design insufficiency - Assign to Null ElementPtr"); // should never occure
                }
            }
            void operator()(const AttributePtr pElement) {
                if (pElement != nullptr) {
                    pElement->m_pElement->SetAttribute(pElement->m_key.c_str(), m_value.c_str());
                }
                else {
                    throw null_element_write_error("Design insufficiency - Assign to Null AttributePtr"); // should never occure
                }
            };
            
        };
        struct element_value_selector : public boost::static_visitor<Value> {
            Value operator()(const NULLElementPtr pElement) const {
                throw null_element_write_error("Can't return null element value.");
            }
            Value operator()(const DocumentPtr pElement) const {
                return this->operator()(pElement->RootElement()); // delegate
            }
            Value operator()(const ElementPtr pElement) const {
                if (pElement != nullptr) {
                    return pElement->GetText();
                }
                else {
                    throw null_element_write_error("Design insufficiency - Value access of Null ElementPtr"); // should never occure
                }
            }
            Value operator()(const AttributePtr pElement) const {
                if (pElement != nullptr) {
                    return pElement->m_pElement->Attribute(pElement->m_key.c_str());
                }
                else {
                    throw null_element_write_error("Design insufficiency - Value access of Null AttributePtr"); // should never occure
                }
            };
            
        };
        
    }
    
    // Todo: Split into public hpp XMLElementView and cpp XMLElementView::impl
    class XMLElementView {
    private:
        ElementPtrVariant m_ElementPtrVariant;
    public:
        template <typename ElementPtr>
        XMLElementView(const ElementPtr& pElement) : m_ElementPtrVariant(pElement) {}
        XMLElementView() : m_ElementPtrVariant() {}
        XMLElementView(const XMLElementView& other) : m_ElementPtrVariant(other.m_ElementPtrVariant) {}
        XMLElementView(XMLElementView&& other) : m_ElementPtrVariant(std::move(other.m_ElementPtrVariant)) {}
        XMLElementView& operator=(const XMLElementView& other) {
            m_ElementPtrVariant = other.m_ElementPtrVariant;
            return *this;
        }
        XMLElementView& operator=(XMLElementView&& other) {
            m_ElementPtrVariant = std::move(other.m_ElementPtrVariant);
            return *this;
        }
        XMLElementView operator[](const Key& key) {
            detail::select_child child_selector(key);
            return boost::apply_visitor(child_selector, m_ElementPtrVariant);
        }
        XMLElementView operator[](const Path& path) {
            XMLElementView result(*this);
            for (auto& key : path) {
                result = result[key]; // traverse childs
            }
            return result;
        }
        bool operator==(const Key& key) const {
            detail::key_matches match_key(key);
            return boost::apply_visitor(match_key, m_ElementPtrVariant);
        }
        
        XMLElementView& operator=(const char* szValue) {
            detail::element_value_assigner assign_element(szValue);
            boost::apply_visitor(assign_element, m_ElementPtrVariant);
            return *this;
        };
        operator bool() {
            return boost::apply_visitor(detail::is_null(), m_ElementPtrVariant);
        }
        
        operator Value() {
            return boost::apply_visitor(detail::element_value_selector(), m_ElementPtrVariant);
        }
    };
    
    class XMLComponent {
    public:
        XMLComponent(const xml_span& span = xml_span());
        XMLElementView operator[](const Path& path);
        operator Value();
    private:
        struct impl;
        std::unique_ptr<impl> pimpl;
    };
    
    
    // Cpp-file
    // ----------------------------------------------------------------------------
    // XMLComponent::impl
    // ----------------------------------------------------------------------------
    struct XMLComponent::impl {
    private:
        tinyxml2::XMLDocument m_XMLDocument;
    public:
        impl(const xml_span& span) : m_XMLDocument() {
            m_XMLDocument.Parse(span.data(),span.length());
            if (span.size() == 0) {
                m_XMLDocument.NewDeclaration();
            }
        }
        XMLElementView operator[](const Path& path) {
            XMLElementView result(&m_XMLDocument);
            return result[path];
        }
        operator bool() const {return m_XMLDocument.RootElement() != nullptr;}
        Value toString() const {
            std::string sResult;
            tinyxml2::XMLPrinter xml_printer;
            m_XMLDocument.Print(&xml_printer);
            return xml_printer.CStr();
        }

    };
    // ----------------------------------------------------------------------------
    // XMLComponent
    // ----------------------------------------------------------------------------
    XMLComponent::XMLComponent(const xml_span& span) : pimpl(new impl(span)) {}
    // ----------------------------------------------------------------------------
    XMLElementView XMLComponent::operator[](const Path& path) {
        return (*pimpl)[path];
    }
    XMLComponent::operator Value() {
        return pimpl->toString();
    }

    // ----------------------------------------------------------------------------
    // TEST
    // ----------------------------------------------------------------------------
    namespace test {
        void execute() {
            XMLComponent xml_component;
            /*
            <?xml version="1.0" encoding="UTF-8"?>
            <SaleToPOIRequest xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="EpasSaleToPOIMessages.xsd">
               <MessageHeader ProtocolVersion="1.0" MessageClass="Service" MessageCategory="Login" MessageType="Request" ServiceID="285" WorkstationID="" POIID="52400053" />
               <LoginRequest OperatorLanguage="sv" OperatorID="Cashier16" ShiftNumber="2" POISerialNumber="78910AA46010005">
                  <DateTime>2016-08-31T13:09:12.4251848+02:00</DateTime>
                  <SaleSoftware ManufacturerID="PointOfSaleCo" ApplicationName="SaleSys" SoftwareVersion="01.98.01" CertificationCode="ECTS2PS001" />
                  <ConfigData>
                     <TxnHostAddress>164.10.203.25:6054</TxnHostAddress>
                     <ConfigHostAddress>164.10.25.253:21</ConfigHostAddress>
                     <ConfigFile />
                  </ConfigData>
               </LoginRequest>
            </SaleToPOIRequest>
             */
            {
                auto e0 = xml_component[{"SaleToPOIRequest"}];
                if (e0) {
                    auto e1 = e0[Path{"@xmlns:xsi"}];
                    if (e1) {
                        e1 = "http://www.w3.org/2001/XMLSchema-instance";
                    }
                    else {
                        std::cout << "\ne1 = Null";
                    }
                }
                else {
                    std::cout << "\ne0 = Null";
                }
                std::cout << std::endl;
            }
            {
                auto e2 = xml_component[{"SaleToPOIRequest","MessageHeader"}];
                if (e2) {
                    auto e3 = e2[Path{"@@ProtocolVersion"}];
                    if (e3) {
                        e3 = "1.0";
                    }
                    else {
                        std::cout << "\ne3 = Null";
                    }
                }
                else {
                    std::cout << "\ne2 = Null";
                }
                std::cout << std::endl;
            }
            
            
            xml_component[{"SaleToPOIRequest","@xmlns:xsi"}] = "http://www.w3.org/2001/XMLSchema-instance";
            xml_component[{"SaleToPOIRequest","@xsi:noNamespaceSchemaLocation"}] = "EpasSaleToPOIMessages.xsd";
            xml_component[{"SaleToPOIRequest","MessageHeader","@ProtocolVersion"}] = "1.0";
            xml_component[{"SaleToPOIRequest","MessageHeader","@MessageClass"}] = "Service";
            xml_component[{"SaleToPOIRequest","MessageHeader","@MessageCategory"}] = "Login";
            xml_component[{"SaleToPOIRequest","MessageHeader","@MessageType"}] = "Request";
            xml_component[{"SaleToPOIRequest","MessageHeader","@ServiceID"}] = "285";
            xml_component[{"SaleToPOIRequest","MessageHeader","@WorkstationID"}] = "";
            xml_component[{"SaleToPOIRequest","MessageHeader","@POIID"}] = "52400053";
            xml_component[{"SaleToPOIRequest","LoginRequest","@OperatorLanguage"}] = "sv";
            xml_component[{"SaleToPOIRequest","LoginRequest","@OperatorID"}] = "Cashier16";
            xml_component[{"SaleToPOIRequest","LoginRequest","@ShiftNumber"}] = "2";
            xml_component[{"SaleToPOIRequest","LoginRequest","@POISerialNumber"}] = "78910AA46010005";
            xml_component[{"SaleToPOIRequest","LoginRequest","DateTime"}] = "2016-08-31T13:09:12.4251848+02:00";
            xml_component[{"SaleToPOIRequest","LoginRequest","SaleSoftware","@ManufacturerID"}] = "PointOfSaleCo";
            xml_component[{"SaleToPOIRequest","LoginRequest","SaleSoftware","@ApplicationName"}] = "SaleSys";
            xml_component[{"SaleToPOIRequest","LoginRequest","SaleSoftware","@SoftwareVersion"}] = "01.98.01";
            xml_component[{"SaleToPOIRequest","LoginRequest","SaleSoftware","@CertificationCode"}] = "ECTS2PS001";
            xml_component[{"SaleToPOIRequest","LoginRequest","ConfigData","TxnHostAddress"}] = "164.10.203.25:6054";
            xml_component[{"SaleToPOIRequest","LoginRequest","ConfigData","ConfigHostAddress"}] = "164.10.25.253:21";
            xml_component[{"SaleToPOIRequest","LoginRequest","ConfigData","ConfigFile"}] = "";
            
            std::cout << Value(xml_component);
            
        }
    }
}

