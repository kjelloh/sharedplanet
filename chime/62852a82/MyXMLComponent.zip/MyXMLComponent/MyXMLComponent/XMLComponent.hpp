//
//  XMLComponent.hpp
//  MyXMLComponent
//
//  Created by Kjell-Olov Högdahl on 2016-10-09.
//  Copyright © 2016 Kjell-Olov Högdahl. All rights reserved.
//

#ifndef XMLComponent_hpp
#define XMLComponent_hpp

namespace xml {
    namespace test {
        void execute();
    }
}

#endif /* XMLComponent_hpp */
