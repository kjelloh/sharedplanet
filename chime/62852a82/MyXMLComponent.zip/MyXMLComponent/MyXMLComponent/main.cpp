//
//  main.cpp
//  MyXMLComponent
//
//  Created by Kjell-Olov Högdahl on 2016-10-09.
//  Copyright © 2016 Kjell-Olov Högdahl. All rights reserved.
//

#include <iostream>
#include "XMLComponent.hpp"


int main(int argc, const char * argv[]) {    
    xml::test::execute();
    return 0;
}
